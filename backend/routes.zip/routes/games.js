// routes/games.js
const express = require('express');
const {
  getGames,
  getGame,
  fetchGames,
  getGamesByTeam,
  filterGames,
  updateGameStatus,
  getWeekGames
} = require('../controllers/games');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Public routes
router.route('/').get(getGames);
router.route('/:id').get(getGame);
router.route('/team/:teamId').get(getGamesByTeam);
router.route('/week/:seasonYear/:weekNumber').get(getWeekGames);
router.route('/filter').get(filterGames);

// Protected routes
router.use(protect);

// Admin only routes
router.route('/fetch').post(authorize('admin'), fetchGames);
router.route('/:id/status').put(authorize('admin'), updateGameStatus);

module.exports = router;